package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.*;


public class test {
    public synchronized static Connection getConnectionByJNDI() {
        Connection con = null;
        try {
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");
//上面写法都是不变的，下面这行中lookup中的字符串就是配置的JNDI名称，
//比如context中的<resource name="xxx">或者web.xml中的<resource-env-ref-name>
            DataSource ds = (DataSource)envCtx.lookup("jdbc/TestWTY");
            con = ds.getConnection();
        } catch (NamingException e) {
            e.printStackTrace();
            System.out.println("连接错误！");
// e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("获取连接失败！");
// e.printStackTrace();
        }
        return con;
    }
    public static void closeResource(ResultSet rs, Statement stmt, Connection con){
        try {
            if(rs != null){
                rs.close();
            }
            if(stmt != null){
                stmt.close();
            }
            if(con != null){
                con.close();
            }
        }catch (SQLException e) {
            System.out.println("关闭资源失败！");
// e.printStackTrace();
        }
    }
    public static String result(){
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String username=null;
        int score=0;
        String degree=null;
        try {
            conn = getConnectionByJNDI();
            ps = conn.prepareStatement("select * from score limit 1");
            rs = ps.executeQuery();
            while(rs.next()){
                username = rs.getString("username");
                score = rs.getInt("score");
                degree = rs.getString("degree");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            closeResource(rs,ps,conn);
        }
        System.out.println(username+score+degree);
        return username+score+degree;
    }
}
