package aa;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        DataSource ds = new MyDataSource();

        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = ds.getConnection();
            ps = conn.prepareStatement("select * from user_score");
            ResultSet rs = ps.executeQuery();
            List<userScore> stuList = new ArrayList<userScore>();
            while(rs.next()){
                userScore us=new userScore();
                String id = rs.getString("id");
                String name = rs.getString("name");
                Double score = rs.getDouble("score");
                us.setId(id);
                us.setName(name);
                us.setScore(score);
                stuList.add(us);
            }
            for (userScore us : stuList) {
                System.out.println(us);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(ps!=null){
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
