package aa;

import java.io.Serializable;

public class userScore implements Serializable {
    private static  final long serialVersionUID=1;
    private String id;
    private String name;
    private  double score;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    @Override
    public String toString(){
        return "user [id=" + id + ", name=" + name + ",score="+score+"]";
    }
}
